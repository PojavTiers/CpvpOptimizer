# CrystalRush 1.21.1

Client-side Fabric mod source project for Minecraft 1.21.1.

## Features
- Clears the vanilla item-use cooldown while an End Crystal is in either hand, allowing normal client input to attempt crystal placement on consecutive client ticks.
- While the attack button is held and the crosshair is on an End Crystal, repeats the normal client attack call once per client tick after the initial click.
- Does not switch hotbar slots, open inventory, change server tick rate, or bypass server-side checks.

## Important limits
Minecraft normally runs at 20 ticks per second. The client can attempt interactions more responsively, but the server controls actual placement and crystal destruction. Ping, server TPS, reach, and server rules still affect the result. This mod cannot guarantee a 70 ms action interval.

## Build
Requires JDK 21 and Gradle 8.x.

From this folder run:
    gradle build

The mod JAR will be created in:
    build/libs/CrystalRush-1.0.0.jar

Put that JAR in your Minecraft `mods` folder alongside Fabric Loader.

## Target
- Minecraft 1.21.1
- Fabric Loader 0.16.5+
- Java 21


## Easiest build on Android (no Termux)
1. Extract this ZIP.
2. Create a GitHub repository in your browser.
3. Upload all extracted project files and folders to the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab and select **Build CrystalRush**.
5. Tap **Run workflow** (or wait for the automatic build after uploading to `main`).
6. When the run finishes, open it and download the `CrystalRush-Fabric-1.21.1` artifact.
7. Extract the downloaded artifact ZIP. Put the `.jar` inside your Minecraft `mods` folder.

If the build fails, open the failed run and share the error log so the source can be fixed.
