package com.crystalrush.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow private int itemUseCooldown;
    @Shadow private abstract boolean doAttack();

    private boolean crystalrush$wasHoldingAttackOnCrystal = false;

    @Inject(method = "tick", at = @At("TAIL"))
    private void crystalrush$fastCrystalInteractions(CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;

        if (client.player == null || client.currentScreen != null) {
            crystalrush$wasHoldingAttackOnCrystal = false;
            return;
        }

        // Clear the vanilla item-use delay while an End Crystal is selected.
        // This does not alter server tick limits or send packets outside normal client ticks.
        boolean holdingCrystal =
                client.player.getMainHandStack().isOf(Items.END_CRYSTAL)
                || client.player.getOffHandStack().isOf(Items.END_CRYSTAL);

        if (holdingCrystal) {
            itemUseCooldown = 0;
        }

        // Continue attacking an End Crystal once per client tick while the attack
        // button is held. The server still decides when it can process each packet.
        boolean aimingAtCrystal =
                client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof EndCrystalEntity;

        boolean holdingAttackOnCrystal =
                aimingAtCrystal && client.options.attackKey.isPressed();

        if (holdingAttackOnCrystal && crystalrush$wasHoldingAttackOnCrystal) {
            doAttack();
        }

        crystalrush$wasHoldingAttackOnCrystal = holdingAttackOnCrystal;
    }
}
